#!/home/alberto-vizcaino/.local/share/mchose-venv/bin/python
"""
MCHOSE Wireless Peripherals Battery Monitor for Linux
Supports:
  - MCHOSE V9 Pro Wireless Headset (C-Media CM2025 DSP, VID: 0x291D, PID: 0x385D)
  - MCHOSE K7 Ultra Wireless Mouse (RealTek SoC, VID: 0x3837, PID: 0x1001)

Features:
  - CLI human-readable output
  - JSON output for Waybar / Polybar / Dunst / Scripts (--json)
  - Waybar specialized modules (--waybar-headset, --waybar-mouse)
"""

import sys
import time
import argparse
import json

try:
    import hid
except ImportError:
    print("Error: 'hidapi' library is missing. Install with: 'uv pip install hidapi' or use the mchose-venv virtual environment.", file=sys.stderr)
    sys.exit(1)


# ==============================================================================
# 1. MCHOSE V9 PRO HEADSET (C-MEDIA CM2025 PROTOCOL)
# ==============================================================================
def get_v9_pro_battery():
    """
    Queries MCHOSE V9 Pro Headset (VID 0x291D, PID 0x385D).
    Protocol:
      - Intercepted on Interface 0 (UsagePage 0xFF90 / Collection 5).
      - Query Packet (64 bytes): [0x55, 0x65, 0x01, 0x00, 0x00, ...]
      - Response Packet (64 bytes): [0x55, 0x65, BATTERY_PCT, CHARGE_STATUS, ...]
        - Byte 2: Battery Percentage (0-100 decimal)
        - Byte 3: Status (1: Charging, 2: Wireless Discharging, 0: Sleep / Disconnected)
    """
    try:
        devices = hid.enumerate(0x291D, 0x385D)
        if not devices:
            return None, "Desconectado"

        target_path = None
        for d in devices:
            if d.get("usage_page") == 0xFF90:
                target_path = d["path"]
                break
        if not target_path:
            target_path = devices[-1]["path"]

        dev = hid.device()
        dev.open_path(target_path)
        dev.write([0x55, 0x65, 0x01] + [0x00] * 61)
        resp = dev.read(64, timeout_ms=300)
        dev.close()

        if resp and len(resp) >= 4 and resp[0] == 0x55 and resp[1] == 0x65:
            battery = resp[2]
            status_code = resp[3]
            if status_code == 1:
                status_str = "Cargando"
            elif status_code == 2:
                status_str = "Descargando"
            else:
                status_str = "En espera"
            return battery, status_str
    except Exception as e:
        return None, f"Error: {e}"

    return None, "Sin respuesta"


# ==============================================================================
# 2. MCHOSE K7 ULTRA MOUSE (REALTEK PROTOCOL)
# ==============================================================================
def get_k7_ultra_battery():
    """
    Queries MCHOSE K7 Ultra Wireless Mouse (VID 0x3837, PID 0x1001).
    Protocol:
      - Interface 2 (UsagePage 0xFF01 / Collection 2).
      - Initialization / Telemetry trigger sequence:
          1. Feature Report 0x11: [0x11, 0xF9] + [0xFF]*19
          2. Feature Report 0x12: [0x12, 0x98] + [0xFF]*63
          3. Feature Report 0x12: [0x12, 0x97] + [0xFF]*63
          4. Feature Report 0x11: [0x11, 0xFB, 0x55] + [0xFF]*18
      - Incoming Telemetry Report 0x13:
          Data payload is XOR masked with 0xFF!
          Decoded = [ReportID, byte1 ^ 0xFF, byte2 ^ 0xFF, ...]
          - Decoded[1] == 0xE2 (Telemetry Header)
          - Decoded[3]: Charge Status (1: Discharging, 2: Charging, 0: Sleep)
          - Decoded[5]: Battery Percentage (0-100 decimal)
          - Decoded[9..]: Product Name String ("K7 Ultra")
    """
    try:
        devices = hid.enumerate(0x3837, 0x1001)
        if not devices:
            return None, "Desconectado"

        target_path = None
        for d in devices:
            if d.get("interface_number") == 2 and d.get("usage_page") == 0xFF01:
                target_path = d["path"]
                break
        if not target_path:
            return None, "Interfaz no encontrada"

        dev = hid.device()
        dev.open_path(target_path)
        dev.set_nonblocking(False)

        seq = [
            [0x11, 0xF9] + [0xFF] * 19,
            [0x12, 0x98] + [0xFF] * 63,
            [0x12, 0x97] + [0xFF] * 63,
            [0x11, 0xFB, 0x55] + [0xFF] * 18,
        ]
        for pkt in seq:
            try:
                dev.send_feature_report(pkt)
                time.sleep(0.015)
            except Exception:
                pass

        for _ in range(8):
            resp = dev.read(64, timeout_ms=150)
            if resp and resp[0] == 0x13:
                decoded = [resp[0]] + [x ^ 0xFF for x in resp[1:]]
                if len(decoded) > 5 and decoded[1] == 0xE2:
                    battery = decoded[5]
                    charge_code = decoded[3]
                    status_str = "Cargando" if charge_code == 2 else "Descargando"
                    dev.close()
                    return battery, status_str
        dev.close()
    except Exception as e:
        return None, f"Error: {e}"

    return None, "Sin respuesta"


# ==============================================================================
# MAIN / CLI / FORMATTERS
# ==============================================================================
def main():
    parser = argparse.ArgumentParser(description="MCHOSE Wireless Peripherals Battery Monitor")
    parser.add_argument("--json", action="store_true", help="Output state in JSON format")
    parser.add_argument("--waybar-headset", action="store_true", help="Waybar custom module JSON for V9 Pro")
    parser.add_argument("--waybar-mouse", action="store_true", help="Waybar custom module JSON for K7 Ultra")
    parser.add_argument("--show-disconnected", action="store_true", help="Show module even if disconnected")
    args = parser.parse_args()

    # Specialized Waybar Headset module
    if args.waybar_headset:
        v9_bat, v9_st = get_v9_pro_battery()
        if v9_bat is not None:
            is_charging = (v9_st == "Cargando")
            icon = "󰂄" if is_charging else "󰋋"
            css_class = "charging" if is_charging else ("low" if v9_bat <= 20 else "discharging")
            print(json.dumps({
                "text": f"{icon} {v9_bat}%",
                "alt": f"{v9_bat}%",
                "tooltip": f"🎧 MCHOSE V9 Pro: {v9_bat}% ({v9_st})",
                "percentage": v9_bat,
                "class": css_class
            }))
        else:
            if args.show_disconnected:
                print(json.dumps({"text": "󰋋 Off", "tooltip": f"MCHOSE V9 Pro: {v9_st}", "class": "disconnected"}))
            else:
                # Return empty text so Waybar hides the module when disconnected
                print(json.dumps({"text": "", "tooltip": f"MCHOSE V9 Pro: {v9_st}", "class": "disconnected"}))
        return

    # Specialized Waybar Mouse module
    if args.waybar_mouse:
        k7_bat, k7_st = get_k7_ultra_battery()
        if k7_bat is not None:
            is_charging = (k7_st == "Cargando")
            icon = "󰂄" if is_charging else "󰍽"
            css_class = "charging" if is_charging else ("low" if k7_bat <= 20 else "discharging")
            print(json.dumps({
                "text": f"{icon} {k7_bat}%",
                "alt": f"{k7_bat}%",
                "tooltip": f"🐭 MCHOSE K7 Ultra: {k7_bat}% ({k7_st})",
                "percentage": k7_bat,
                "class": css_class
            }))
        else:
            if args.show_disconnected:
                print(json.dumps({"text": "󰍽 Off", "tooltip": f"MCHOSE K7 Ultra: {k7_st}", "class": "disconnected"}))
            else:
                # Return empty text so Waybar hides the module when disconnected
                print(json.dumps({"text": "", "tooltip": f"MCHOSE K7 Ultra: {k7_st}", "class": "disconnected"}))
        return

    v9_bat, v9_st = get_v9_pro_battery()
    k7_bat, k7_st = get_k7_ultra_battery()

    if args.json:
        print(json.dumps({
            "headset": {"name": "MCHOSE V9 Pro", "battery": v9_bat, "status": v9_st},
            "mouse": {"name": "MCHOSE K7 Ultra", "battery": k7_bat, "status": k7_st}
        }, indent=2))
        return

    # Standard human-readable CLI output
    print("┌──────────────────────────────────────────────┐")
    print("│         MCHOSE WIRELESS DEVICE STATUS        │")
    print("├──────────────────────────────────────────────┤")
    if v9_bat is not None:
        print(f"│  🎧 Auriculares V9 Pro : {v9_bat:>3}%  [{v9_st:<12}] │")
    else:
        print(f"│  🎧 Auriculares V9 Pro : ⚠️  {v9_st:<17} │")

    if k7_bat is not None:
        print(f"│  🐭 Ratón K7 Ultra     : {k7_bat:>3}%  [{k7_st:<12}] │")
    else:
        print(f"│  🐭 Ratón K7 Ultra     : ⚠️  {k7_st:<17} │")
    print("└──────────────────────────────────────────────┘")


if __name__ == "__main__":
    main()
